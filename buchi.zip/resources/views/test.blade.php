

<?php
    $world= "hi ariyan";
    echo $world;

?>
    {{ $world }}

    if($world) {

    } else {



    }

    @if()

    @endif

    

    @foreach 

    @endforeach
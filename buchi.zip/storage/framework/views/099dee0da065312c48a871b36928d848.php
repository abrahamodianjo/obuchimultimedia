<!doctype html>
<html class="no-js" lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title><?php echo $__env->yieldContent('title'); ?></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="x-ua-compatible" content="ie=edge" />
        <meta name="title" content="O'Buchi Multimedia" />
        <meta name="author" content="Abraham Odianjo" />
        <meta name="keywords" content="Abuja, grahpics design, web development, website developmenent, photography, videography, content creation, social media, " />
        <meta name="description" content="This is O'Buchi Multimedia website. This site is used and runned by the odianjo family, we offer the services as seen below on the website. So feel free to reach us for further businesses." />

        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta property="og:title" content="" />
        <meta property="og:type" content="" />
        <meta property="og:url" content="" />
        <meta property="og:image" content="" />
		<link rel="shortcut icon" type="image/x-icon" href="  <?php echo e(asset('frontend/assets/img/favicon.png')); ?>">
        <!-- Place favicon.ico in the root directory -->

		<!-- CSS here -->
        <link rel="stylesheet" href="  <?php echo e(asset('frontend/assets/css/bootstrap.min.css')); ?>">
        <link rel="stylesheet" href="  <?php echo e(asset('frontend/assets/css/animate.min.css')); ?>">
        <link rel="stylesheet" href="  <?php echo e(asset('frontend/assets/css/magnific-popup.css')); ?>">
        <link rel="stylesheet" href="  <?php echo e(asset('frontend/assets/css/fontawesome-all.min.css')); ?>">
        <link rel="stylesheet" href="  <?php echo e(asset('frontend/assets/css/slick.css')); ?>">
        <link rel="stylesheet" href="  <?php echo e(asset('frontend/assets/css/default.css')); ?>">
        <link rel="stylesheet" href="  <?php echo e(asset('frontend/assets/css/style.css')); ?>">
        <link rel="stylesheet" href="  <?php echo e(asset('frontend/assets/css/responsive.css')); ?>">
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css" >
       
       
    </head>
    <body>

        <!-- preloader-start -->
        <div id="preloader">
            <div class="rasalina-spin-box"></div>
        </div>
        <!-- preloader-end -->

		<!-- Scroll-top -->
        <button class="scroll-top scroll-to-target" data-target="html">
            <i class="fas fa-angle-up"></i>
        </button>
        <!-- Scroll-top-end-->

        <!-- header-area -->
    <?php echo $__env->make('frontend.body.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- header-area-end -->

        <!-- main-area -->
        <main>
            <?php echo $__env->yieldContent('main'); ?>

        </main>
        <!-- main-area-end -->



        <!-- Footer-area -->
      <?php echo $__env->make('frontend.body.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Footer-area-end -->




		<!-- JS here -->
		
		 <script src="//code.tidio.co/0hyx55lmhcfnsebg6lbwpaqutbe9tv2a.js" async></script>
        <script src=" <?php echo e(asset('frontend/assets/js/vendor/jquery-3.6.0.min.js')); ?>"></script>
        <script src=" <?php echo e(asset('frontend/assets/js/bootstrap.min.js')); ?>"></script>
        <script src=" <?php echo e(asset('frontend/assets/js/isotope.pkgd.min.js')); ?>"></script>
        <script src=" <?php echo e(asset('frontend/assets/js/imagesloaded.pkgd.min.js')); ?>"></script>
        <script src=" <?php echo e(asset('frontend/assets/js/jquery.magnific-popup.min.js')); ?>"></script>
        <script src=" <?php echo e(asset('frontend/assets/js/element-in-view.js')); ?>"></script>
        <script src=" <?php echo e(asset('frontend/assets/js/slick.min.js')); ?>"></script>
        <script src=" <?php echo e(asset('frontend/assets/js/ajax-form.js')); ?>"></script>
        <script src=" <?php echo e(asset('frontend/assets/js/wow.min.js')); ?>"></script>
        <script src=" <?php echo e(asset('frontend/assets/js/plugins.js')); ?>"></script>
        <script src=" <?php echo e(asset('frontend/assets/js/main.js')); ?>"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

        <script>
            <?php if(Session::has('message')): ?>
                var type = "<?php echo e(Session::get('alert-type','info')); ?>"
                switch(type){
                    case 'info':
                    toastr.info(" <?php echo e(Session::get('message')); ?> ");
                    break;

                    case 'success':
                    toastr.success(" <?php echo e(Session::get('message')); ?> ");
                    break;

                    case 'warning':
                    toastr.warning(" <?php echo e(Session::get('message')); ?> ");
                    break;

                    case 'error':
                    toastr.error(" <?php echo e(Session::get('message')); ?> ");
                    break; 
            }
            <?php endif; ?> 
        </script>
            <!--tinymce js-->
    </body>
</html>
<?php /**PATH /home/galarfla/obuchimultimedia.com/resources/views/frontend/main_master.blade.php ENDPATH**/ ?>

<?php $__env->startSection('admin'); ?>


<div class="page-content">
    <div class="container-fluid">
    <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0">Multi Image All</h4>

                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">Tables</a></li>
                                            <li class="breadcrumb-item active">Data Tables</li>
                                        </ol>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- end page title -->
                        
                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
        
                                        <h4 class="card-title">Multi Image All</h4>
                                        
        
                                        <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                            <thead>
                                            <tr>
                                                <th>S/No</th>
                                                <th>About Multi Image</th>
                                                <th>Action</th>
                                                
                                            </tr>
                                            </thead>
        
        
                                            <tbody>
                                                <?php ($i = 1); ?>
                                                <?php $__currentLoopData = $allMultiImage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                           
                                            <tr>
                                                <td><?php echo e($i++); ?></td>
                                                <td><img src="<?php echo e(asset($item->multi_image)); ?>" style="width: 60px; height: 60px;"></td>
                                                <td>
                                                    <a href="<?php echo e(route('edit.multi.image', $item->id)); ?>"  class="btn btn-info sm" title="Edit Data"> <i class="fas fa-edit"></i> </a>
                                                    <a href="<?php echo e(route('delete.multi.image', $item->id)); ?>"  class="btn btn-danger sm" title="Delete Data" id="delete"> <i class="fas fa-trash-alt "></i> </a>
                                                </td>
                                           
                                            </tr>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
        
                                    </div>
                                </div>
                            </div> <!-- end col -->
                        </div> <!-- end row -->

                    </div> <!-- container-fluid -->
                </div>

    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project1\basic\resources\views/admin/about_page/all_multiimage.blade.php ENDPATH**/ ?>
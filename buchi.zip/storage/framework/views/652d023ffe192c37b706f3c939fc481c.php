
<?php $__env->startSection('admin'); ?>


<div class="page-content">
    <div class="container-fluid">
    <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0">All Contact Messages </h4>

                                

                                </div>
                            </div>
                        </div>
                        <!-- end page title -->
                        
                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
        
                                        <h4 class="card-title">Contact Messages</h4>
                                        
        
                                        <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                            <thead>
                                            <tr>
                                                <th>S/No</th>
                                                <th>Name</th>
                                                <th>Email</th>
                                                <th>Phone</th>
                                                <th>Date</th>
                                                <th>Action</th>
                                                
                                            </tr>
                                            </thead>
        
        
                                            <tbody>
                                                <?php ($i = 1); ?>
                                                <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                           
                                            <tr>
                                                <td><?php echo e($i++); ?></td>
                                                <td><?php echo e($item->name); ?></td>
                                                <td><?php echo e($item->email); ?></td>
                                                <td><?php echo e($item->phone); ?></td>
                                               
                                                <td><?php echo e(Carbon\Carbon::parse($item->created_at)->diffForHumans()); ?></td>
                                                <td>
                                                <a href="<?php echo e(route('open.message', $item->id)); ?>"  class="btn btn-primary sm" title="Open Data"> <i class="ri-mail-open-fill"></i> </a>
                                              <a href="<?php echo e(route('delete.message', $item->id)); ?>"  class="btn btn-danger sm" title="Delete Data" id="delete"> <i class="fas fa-trash-alt "></i> </a>
                                                </td>
                                           
                                            </tr>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
        
                                    </div>
                                </div>
                            </div> <!-- end col -->
                        </div> <!-- end row -->

                    </div> <!-- container-fluid -->
                </div>

    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/galarfla/obuchimultimedia.com/resources/views/admin/contact/allcontact.blade.php ENDPATH**/ ?>
<footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-sm-6">
                               O'Buchi Multimedia Ltd © Upcube.
                            </div>
                            <div class="col-sm-6">
                                <div class="text-sm-end d-none d-sm-block">
                                    Crafted with <i class="mdi mdi-heart text-danger"></i> by Abraham Odianjo
                                </div>
                            </div>
                        </div>
                    </div>
                </footer><?php /**PATH /home/vagrant/code/basic/resources/views/admin/body/footer.blade.php ENDPATH**/ ?>
<?php echo e($slot); ?>

<?php /**PATH /home/galarfla/obuchimultimedia.com/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>
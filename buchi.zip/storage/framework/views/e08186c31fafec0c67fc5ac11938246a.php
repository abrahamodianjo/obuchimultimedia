<?php

$allfooter = App\Models\Footer::find(1);

?>

<footer class="footer">
            <div class="container">
                <div class="row justify-content-between">
                    <div class="col-lg-4">
                        <div class="footer__widget">
                            <div class="fw-title">
                                <h5 class="sub-title">Contact us</h5>
                                
                            </div>
                            <div class="footer__widget__text">
                                <p><?php echo e($allfooter->short_description); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-4 col-sm-6">
                        <div class="footer__widget">
                            <div class="fw-title">
                                <h5 class="sub-title">my address</h5>
                               
                            </div>
                            <div class="footer__widget__address">
                                <p class="mail"><?php echo e($allfooter->address); ?></p>
                                <p class="mail"><?php echo e($allfooter->number); ?></p>
                                <a href="mailto:<?php echo e($allfooter->email); ?>" class="mail"><?php echo e($allfooter->email); ?></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-4 col-sm-6">
                        <div class="footer__widget">
                            <div class="fw-title">
                                <h5 class="sub-title">Follow us</h5>
                             
                            </div>
                            <div class="footer__widget__social">
                                
                                <ul class="footer__social__list">
                                    <li><a href="<?php echo e($allfooter->facebook); ?>" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="<?php echo e($allfooter->linkedin); ?>" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
                                    <li><a href="<?php echo e($allfooter->instagram); ?>" target="_blank"><i class="fab fa-instagram"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="copyright__wrap">
                    <div class="row">
                        <div class="col-12">
                            <div class="copyright__text text-center">
                                <p><?php echo e($allfooter->copyright); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer><?php /**PATH C:\xampp\htdocs\Project1\basic\resources\views/frontend/body/footer.blade.php ENDPATH**/ ?>